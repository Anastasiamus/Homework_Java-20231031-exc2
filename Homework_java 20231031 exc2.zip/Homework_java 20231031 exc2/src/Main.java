public class Main {
    public static void main(String[] args) {
        String str = new String("I study Basic Java !");
        
        System.out.println(str.charAt(str.length()-1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replace('a', '0'));
        System.out.println(str.toUpperCase());
        System.out.println(str.toLowerCase());
        System.out.println(str.substring(str.trim().lastIndexOf("")+1));

    }
    private static String string(String str){
        str = str.intern();
        return str;
    }
}


//Задание 2. Создайте строку через new - I study Basic Java!
//Напишите метод, который принимает в качестве параметра строку, передайте в этот метод созданную строку
//
//
//
//Распечатать последний символ строки. Используем метод String.charAt().
//
//Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
//
//Заменить все символы “а” на “о”.
//
//Преобразуйте строку к верхнему регистру.
//
//Преобразуйте строку к нижнему регистру.
//
//Вырезать строку Java c помощью метода String.substring().